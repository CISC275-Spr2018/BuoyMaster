package main;
import javax.swing.JPanel;

public class QuestionScreen extends JPanel{

}
