package main;

public class CorrectListener{
	public CorrectListener(){
		
	}	
}