package main;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FactScreen extends JPanel{
	JLabel fact = new JLabel("steam both sides of the L");
	
	
	FactScreen(){
		this.add(fact);
	}
}
