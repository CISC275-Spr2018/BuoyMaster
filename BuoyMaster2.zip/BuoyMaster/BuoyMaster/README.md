# BuoyMaster
Choose your boat and collect the data, but be careful about how much erosion you cause.
